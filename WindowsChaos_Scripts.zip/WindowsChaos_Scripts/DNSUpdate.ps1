$Date = Get-Date
$primaryDNS = Read-Host -Prompt 'Please ener the Primary DNS IP Address'

$secondaryDNS = Read-Host -Prompt 'Please ener the Secondary DNS IP Address'

write-Host "The script will set the new DNS entries for  $env:computername"

$msg ='Please confirm [Y/N]'
do {
    $response = Read-Host -Prompt $msg
    if ($response.ToLower() -eq 'y') {
        # prompt for name/address and add to certificate
		Set-DnsClientServerAddress -InterfaceAlias Ethernet -ServerAddresses "$primaryDNS","$secondaryDNS"
		write-host "Task completed successfully"
	Exit
    }
} until ($response.ToLower() -eq 'n')