$Drives = Get-PSDrives
$E Drive = Read-Host -Prompt 'Please ener the File size'

write-Host "System.IO.File -FilePath E:\test.txt -Size"

$msg ='Please confirm [Y/N]'
do {
    $file = [System.IO.File]::Create($FilePath)
   $file.SetLength($Size)
   $file.Close()
   Get-Item $file.Name"
		write-host "Task completed successfully"
	Exit
