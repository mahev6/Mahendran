#$Server = Read-Host -Prompt 'Input your server  name'
#$User = Read-Host -Prompt 'Input the user name'
#$Date = Get-Date
#Write-Host "You input server '$Server'  on '$Date'"

$Date = Get-Date
$processName = Read-Host -Prompt 'Please ener the process name to stop'
write-Host "The process '$processName' is going to stop."
$msg ='Please confirm [Y/N]'
do {
    $response = Read-Host -Prompt $msg
    if ($response.ToLower() -eq 'y') {
        # prompt for name/address and add to certificate
	taskkill /f /IM  "$processName"
	Exit
    }
} until ($response.ToLower() -eq 'n')