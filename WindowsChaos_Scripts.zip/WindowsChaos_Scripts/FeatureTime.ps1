$Date = Get-Date
write-Host "Current system Date and Time is $Date"

write-Host "The script will set the time  to feature time"
$msg ='Would you like to continue with the test, Please confirm [Y/N]'

do {
    $response = Read-Host -Prompt $msg
   
    if ( $response.ToLower() -eq 'y') {
	
	Set-Date -Date (Get-Date).AddHours(1)

    $Date = Get-Date
	write-Host "Current system Date and Time is $Date"
	write-host "Task completed successfully"
	Exit
    }
} until ( $response.ToLower() -eq 'n')

