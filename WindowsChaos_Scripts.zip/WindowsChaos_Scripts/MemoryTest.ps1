$Date = Get-Date
$Servers = @("localhost")

foreach ($Server in $Servers){

$OS = get-wmiobject -Namespace "root\cimv2" -Class Win32_OperatingSystem -Impersonation 3 -computername $Server

foreach ($Item in $OS){
        $RAM = "{0:N6}" -f ($Item.TotalVisibleMemorySize)/1kB
        $FREE = "{0:N6}" -f ($Item.FreePhysicalMemory)/1kB
        $Server + "`t" + "{0:P0}" -f ($FREE/$RAM)
        }
}

$memoryValue = Read-Host -Prompt 'Please enter how much memory would like to consume[E.g for 1GB, please enter as 1024]'
write-Host "The script will consume '$memoryValue' MB of memory."
$msg ='Would you like to continue with the test, Please confirm [Y/N]'
do {
    $response = Read-Host -Prompt $msg
   
    if ( $response.ToLower() -eq 'y') {
	tools\testlimit64.exe -d -c $memoryValue

	write-host "Task completed successfully"
    }
} until ( $response.ToLower() -eq 'n')