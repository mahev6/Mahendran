$Date = Get-Date
write-Host "Current system date is $Date"

write-Host "The script will set the date to past date"
$msg ='Would you like to continue with the test, Please confirm [Y/N]'

do {
    $response = Read-Host -Prompt $msg
   
    if ( $response.ToLower() -eq 'y') {
	
	Set-Date -Date (Get-Date).AddDays(-1)

    $Date = Get-Date
	write-Host "Current system date is $Date"
	write-host "Task completed successfully"
	Exit
    }
} until ( $response.ToLower() -eq 'n')

