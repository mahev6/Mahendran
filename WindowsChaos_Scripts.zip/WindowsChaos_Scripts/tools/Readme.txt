﻿MultiCpuLoad readme file

This program use is for free.

It is not licensed for redistribution on public web sites.
Its only safe and legal source is ristaino.net web site.

The 3 programs contained in this zip archive file are the same.
They only differ by the Microsoft .NET Framework version they require.
These 3 versions are published for maximum compatibility with various 
Windows versions and system setups.

If you launch a program that requires a Microsoft .NET Framework version that
is not installed on your system, it will display an error message, then stop.
There is no easy way to know what .NET Framework versions are installed on a Windows system.
So, try the first program in the following list. If it does not run, then try next one.

MultiCpuLoad45.exe requires Microsoft .NET framework 4.5
MultiCpuLoad35.exe requires Microsoft .NET framework 3.5
MultiCpuLoad20.exe requires Microsoft .NET framework 2.0